const fetchData = require('./scrapper.js');
const urls = require('./site-urls.json');
const fetch = require('node-fetch');
const _cliProgress = require('cli-progress');

let MULTI_SIZE = 1;
const basePath = 'https://www.queroquero.com.br';

const bar1 = new _cliProgress.SingleBar({}, _cliProgress.Presets.shades_classic);

(async () => {
    try {
        const totalElementsToVisit = await fetchData();
        console.log(`\n\nFile was saved successfully - DONE!`);

        bar1.start(totalElementsToVisit, 0);

        let startCount = 0;
        let endCount = MULTI_SIZE;

        const iterateCount = () => {
            let promises = [];

            for (let i = startCount, n=endCount; i<n; i++) {
                const item = urls[i];

                if (!item) {
                    continue;
                }

                promises.push(fetch(`${basePath}${item.url}?_escaped_fragment_`))
            }

            Promise.all(promises).then(response => {
                //console.log(response);
                startCount = startCount + MULTI_SIZE;
                endCount = endCount + MULTI_SIZE;
                iterateCount();
                bar1.update(startCount);
            });
        };
        
        iterateCount();
    } catch(err) {
        console.log(err);
    }
})();