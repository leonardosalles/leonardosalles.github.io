const fs = require('fs');
const fetch = require('node-fetch');
const defaultSitePages = require('./default-site-pages.json');
const categories = require('./categories.json');
const _cliProgress = require('cli-progress');

const url = `https://msb.queroquero.com.br/msb/ecmListagemProduto/v1/listarProduto`;

const bar1 = new _cliProgress.SingleBar({}, _cliProgress.Presets.shades_classic);

const fetchData = () => {
    return new Promise(async(resolve, reject) => {
        const response = await fetch(`${url}?page=0&size=1`);

        if (response.ok) {
            const data = await response.json();

            const totalElements = data.page.totalElements;
            const totalPages = Math.round(totalElements / 1000);

            console.log(`${totalPages} pages found for size 1000 - Generating urls...`)

            bar1.start(totalPages, 0);
            
            let finalResponse = [];

            for (let i=0; i<totalPages; i++) {
                const allData = await fetch(`${url}?page=${i}&size=1000`);
                const responseData = await allData.json();

                for (let item of responseData.results) {
                    const descriptionUrl = getUrlFromDescription(item.descricao || item.descricaoComercial);

                    if (descriptionUrl) {
                        finalResponse.push({
                            url: `/produto/${item.id}/${descriptionUrl}`
                        });
                    }
                }

                bar1.update(i + 1);
            }

            console.log(`\n\nDone, saving JSON...`);

            const siteUrls = [...defaultSitePages, ...categories, ...finalResponse];

            fs.writeFile('site-urls.json', JSON.stringify(siteUrls), 'utf8', err => {
                if (err) {
                    return reject(err);
                }

                resolve(totalElements);
            });
        }
    });
};

function getUrlFromDescription(str, parseComma) {
    if (!str) {
      return;
    }

    str = str.trim();
    str = str.toLowerCase();
    str = str.replace(/[àáâãäåâ]/g, 'a');
    str = str.replace(/[èéêë]/g, 'e');
    str = str.replace(/[ìíîï]/g, 'i');
    str = str.replace(/[òóôöõ]/g, 'o');
    str = str.replace(/[ùú]/g, 'u');
    str = str.replace(/[ç]/g, 'c');
    str = str.replace(/[\/]/gi, '-');

    str = str.replaceAll(' ', '-');
    str = str.replaceAll(',', parseComma ? '-'  : '');
    str = str.replaceAll('.', '');
    str = str.replaceAll('\'', '');
    str = str.replaceAll('-|-', '-');
    str = str.replaceAll('"', '');
    str = str.replaceAll('--', '-');
    str = str.replaceAll('!', '');
    str = str.replaceAll('%', '');
    str = str.replaceAll('@', '');

    return str;
}

String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};

module.exports = fetchData;