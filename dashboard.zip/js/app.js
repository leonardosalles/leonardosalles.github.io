'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

(function () {
	'use strict';

	angular.module('acnf.components', []);
})();

angular.module('acnf.controllers', []);

var dependencies = ['acnf.ui.framework', 'acnf.components', 'acnf.common', 'acnf.controllers', 'acnf.login', 'acnf.inicio', 'acnf.empresa', 'acnf.cadastros', 'acnf.vendas'];

angular.module('acnf.ui', dependencies).run(["$acnfHeader", "$acnfSidebar", "$acnfSecurity", "$rootScope", "$acnfNavigation", "$localStorage", "$sessionStorage", "$location", "$acnfScroll", function ($acnfHeader, $acnfSidebar, $acnfSecurity, $rootScope, $acnfNavigation, $localStorage, $sessionStorage, $location, $acnfScroll) {
	"ngInject";

	$acnfHeader.setLogo('images/logo.png');

	$acnfHeader.setMenuItems([{ id: 'inicio', text: 'Início', href: '/inicio', icon: 'home' }]);

	$acnfNavigation.otherwise('inicio');

	var logged = $localStorage.logged || $sessionStorage.logged;

	if (logged && logged.roles) {
		$acnfSecurity.setRoles(logged.roles);
	}

	var checkLogin = function checkLogin(e, toState, toParams, fromState, fromParams) {
		if (toState.url === '/login' || $rootScope.logged) {
			return;
		}

		if (logged && toState) {
			$rootScope.header.logged = {
				name: logged.name
			};

			$rootScope.token = logged.token;
			$rootScope.logged = logged;
			$location.path(toState.url);
		} else {
			$location.path('/login');
		}
	};

	checkLogin(null, {});

	$rootScope.$on('$stateChangeStart', function (e, toState, toParams, fromState, fromParams) {
		checkLogin(e, toState, toParams, fromState, fromParams);
	});

	$rootScope.logout = function () {
		localStorage.clear();
		sessionStorage.clear();
		$rootScope.logged = null;

		$acnfSecurity.clear();
		$location.path('/login').replace();
	};
}]).config(["$httpProvider", "$config", function ($httpProvider, $config) {
	"ngInject";

	$httpProvider.interceptors.push(["$rootScope", function ($rootScope) {
		return {
			'request': function request(config) {
				if (config.url && config.url.indexOf($config.cepApi) === -1) {
					config.headers.Authorization = 'Basic ' + $rootScope.token;
				}

				return config;
			}
		};
	}]);
}]).constant('$config', {
	api: 'http://host1.acnf.com.br:8080',
	cepApi: 'https://viacep.com.br/'
});

angular.element(document).ready(function () {
	angular.bootstrap(document, ['acnf.ui']);
});

var CadastrosModule = function (_AcnfModule) {
	_inherits(CadastrosModule, _AcnfModule);

	function CadastrosModule($stateProvider, $acnfSidebarProvider) {
		_classCallCheck(this, CadastrosModule);

		var _this = _possibleConstructorReturn(this, (CadastrosModule.__proto__ || Object.getPrototypeOf(CadastrosModule)).call(this));

		_this.$stateProvider = $stateProvider;

		_this.setMainState('cadastros', '/cadastros', {
			sidebar: function sidebar($acnfSidebar) {
				var sidebar = [{ header: 'Cadastros' }, { text: 'Clientes', href: 'clientes', icon: 'user' }, { text: 'Produtos', href: 'produtos', icon: 'tags' }, { text: 'Relatórios', href: 'relatorios', icon: 'file-text-o' }, { text: 'Configurações', href: 'configuracoes', icon: 'cog' }];

				$acnfSidebar.setItems(sidebar);
				$acnfSidebar.setParent('cadastros');
			}
		});

		// CLIENTES
		_this.states.push({
			name: 'cadastros.clientes',
			url: '/clientes',
			templateUrl: 'app/cadastros/clientes/clientes.html',
			controller: 'CadastrosClientesController',
			roles: ['logged', 'consultar_lista_empresas']
		});

		_this.states.push({
			name: 'cadastros.clientes.novo',
			url: '/novo',
			templateUrl: 'app/cadastros/clientes/clientes-administrar.html',
			controller: 'CadastrosClientesAdministrarController',
			roles: ['logged']
		});

		_this.states.push({
			name: 'cadastros.clientes.editar',
			url: '/editar/:id',
			templateUrl: 'app/cadastros/clientes/clientes-administrar.html',
			controller: 'CadastrosClientesAdministrarController',
			roles: ['logged']
		});

		// PRODUTOS
		_this.states.push({
			name: 'cadastros.produtos',
			url: '/produtos',
			templateUrl: 'app/cadastros/produtos/produtos.html',
			controller: 'CadastrosProdutosController',
			roles: ['logged']
		});

		_this.states.push({
			name: 'cadastros.produtos.novo',
			url: '/novo',
			templateUrl: 'app/cadastros/produtos/produtos-administrar.html',
			controller: 'CadastrosProdutosAdministrarController',
			roles: ['logged']
		});

		_this.states.push({
			name: 'cadastros.produtos.editar',
			url: '/editar/:id',
			templateUrl: 'app/cadastros/produtos/produtos-administrar.html',
			controller: 'CadastrosProdutosAdministrarController',
			roles: ['logged']
		});

		_this.setStates();
		return _this;
	}

	_createClass(CadastrosModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider, $acnfSidebarProvider) {
			return new CadastrosModule($stateProvider, $acnfSidebarProvider);
		}
	}]);

	return CadastrosModule;
}(AcnfModule);

angular.module('acnf.cadastros', []).config(CadastrosModule.moduleFactory);

var EmpresaController = function (_AcnfController) {
	EmpresaController.$inject = ["$scope", "$acnfNotify", "$acnfSidebar", "$rootScope", "listaEstados", "listaTipoPessoa", "listaMunicipios", "listaTipoEmissao", "Empresas"];
	_inherits(EmpresaController, _AcnfController);

	function EmpresaController($scope, $acnfNotify, $acnfSidebar, $rootScope, listaEstados, listaTipoPessoa, listaMunicipios, listaTipoEmissao, Empresas) {
		_classCallCheck(this, EmpresaController);

		var _this2 = _possibleConstructorReturn(this, (EmpresaController.__proto__ || Object.getPrototypeOf(EmpresaController)).call(this));

		_this2.$scope = $scope;
		_this2.$scope.isLoading = true;
		_this2.$scope.listaEstados = listaEstados.query();
		_this2.$scope.listaTipoPessoa = listaTipoPessoa.query();
		_this2.$scope.listaTipoEmissao = listaTipoEmissao.query();

		_this2.$acnfNotify = $acnfNotify;
		_this2.Empresas = Empresas;

		var promise = _this2.Empresas.get({ idEmpresa: $rootScope.logged.idEmpresa }).$promise;

		promise.then(function (response) {
			_this2.$scope.entity = response;

			if (_this2.$scope.entity && _this2.$scope.entity.idEnumEstado) {
				var selected = listaEstados.get(_this2.$scope.entity.idEnumEstado);
				_this2.$scope.selectedUF = selected.sigla.toUpperCase();
			}

			if (_this2.$scope.entity.inscricaoEstadual && _this2.$scope.entity.inscricaoEstadual === 'ISENTO') {
				_this2.$scope.isIeIsento = true;
			}
		}).finally(function () {
			_this2.$scope.isLoading = false;
		});

		$acnfSidebar.setItems(null);

		_this2.init();

		// Eventos de Busca de CEP
		_this2.$scope.$on('cep.loaded', function (event, params) {
			var data = params.data;

			if (!data.erro) {
				_this2.municipioFromCep = parseInt(data.ibge, 10);
				_this2.$scope.entity.idEnumEstado = data.idEnumEstado;
				_this2.$scope.entity.endereco = data.logradouro;
				_this2.$scope.entity.bairro = data.bairro;
				_this2.$scope.entity.complemento = data.complemento;
			}
		});

		_this2.$scope.$on('cep.loading', function (event, params) {
			if (params.loading) {
				_this2.$scope.entity.idEnumEstado = null;
				_this2.$scope.entity.endereco = null;
				_this2.$scope.entity.bairro = null;
				_this2.$scope.entity.complemento = null;
			}

			_this2.$scope.isLoadingCep = params.loading;
		});

		_this2.$scope.$on('municipios.loaded', function () {
			if (_this2.municipioFromCep) {
				_this2.$scope.entity.idEnumMunicipio = _this2.municipioFromCep;
			}
		});
		return _this2;
	}

	_createClass(EmpresaController, [{
		key: 'salvar',
		value: function salvar() {
			var _this3 = this;

			if (this.$scope.formEmpresa && this.$scope.formEmpresa.$invalid) {
				return;
			}

			this.$scope.isLoading = true;

			var promise = this.Empresas.update(this.$scope.entity).$promise;
			promise.then(function () {
				_this3.$acnfNotify.success('Salvo com sucesso.');
			}, function () {
				_this3.$acnfNotify.error('Erro ao salvar.');
			}).finally(function () {
				_this3.$scope.isLoading = false;
			});
		}
	}]);

	return EmpresaController;
}(AcnfController);

angular.module('acnf.controllers').controller('EmpresaController', EmpresaController);

var EmpresaModule = function () {
	function EmpresaModule($stateProvider) {
		_classCallCheck(this, EmpresaModule);

		$stateProvider.state('empresa', {
			url: '/empresa',
			templateUrl: 'app/empresa/empresa.html',
			controller: 'EmpresaController'
		});
	}

	_createClass(EmpresaModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new EmpresaModule($stateProvider);
		}
	}]);

	return EmpresaModule;
}();

angular.module('acnf.empresa', []).config(EmpresaModule.moduleFactory);

var InicioController = function InicioController($scope, $acnfHeader, $acnfSidebar) {
	_classCallCheck(this, InicioController);

	this.$scope = $scope;

	$acnfSidebar.setItems(null);
};
InicioController.$inject = ["$scope", "$acnfHeader", "$acnfSidebar"];

angular.module('acnf.controllers').controller('InicioController', InicioController);

var InicioModule = function () {
	function InicioModule($stateProvider) {
		_classCallCheck(this, InicioModule);

		$stateProvider.state('inicio', {
			url: '/inicio',
			templateUrl: 'app/inicio/inicio.html',
			controller: 'InicioController as vm',
			roles: ['logged']
		});
	}

	_createClass(InicioModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new InicioModule($stateProvider);
		}
	}]);

	return InicioModule;
}();

angular.module('acnf.inicio', []).config(InicioModule.moduleFactory);

var LoginController = function (_AcnfController2) {
	LoginController.$inject = ["$scope", "$http", "$acnfSidebar", "$acnfNotify", "$acnfSecurity", "$localStorage", "$location", "$rootScope", "$sessionStorage", "$base64", "Login"];
	_inherits(LoginController, _AcnfController2);

	function LoginController($scope, $http, $acnfSidebar, $acnfNotify, $acnfSecurity, $localStorage, $location, $rootScope, $sessionStorage, $base64, Login) {
		_classCallCheck(this, LoginController);

		var _this4 = _possibleConstructorReturn(this, (LoginController.__proto__ || Object.getPrototypeOf(LoginController)).call(this));

		_this4.$scope = $scope;
		_this4.$http = $http;
		_this4.$localStorage = $localStorage;
		_this4.$sessionStorage = $sessionStorage;
		_this4.$location = $location;
		_this4.$rootScope = $rootScope;
		_this4.$base64 = $base64;
		_this4.$acnfNotify = $acnfNotify;
		_this4.$acnfSecurity = $acnfSecurity;
		_this4.Login = Login;

		$acnfSidebar.setItems(null);

		_this4.init();

		var params = $location.search();
		if (params.usuario && params.senha) {
			_this4.$scope.entity = {};
			_this4.$scope.entity.usuario = params.usuario;
			_this4.$scope.entity.senha = params.senha;

			_this4.login();
		}
		return _this4;
	}

	_createClass(LoginController, [{
		key: 'login',
		value: function login() {
			var _this5 = this;

			if (this.$scope.formLogin && this.$scope.formLogin.$invalid) {
				return;
			}

			var userHash = this.$base64.encode(this.$scope.entity.usuario + ':' + this.$scope.entity.senha);
			this.$rootScope.token = userHash;

			this.Login.get({}, function (response) {
				var storage = _this5.$scope.entity.lembrar ? _this5.$localStorage : _this5.$sessionStorage;

				var roles = ['logged'];

				if (response.permissoes) {
					roles = roles.concat(response.permissoes);
				}

				_this5.$acnfSecurity.setRoles(roles);

				storage.logged = {
					idEmpresa: response.idEmpresa,
					name: response.username,
					roles: roles,
					token: _this5.$rootScope.token
				};

				_this5.$rootScope.header.logged = {
					name: response.username
				};

				_this5.$rootScope.logged = storage.logged;
				_this5.$location.search({});
				_this5.$location.path('/inicio').replace();
			}, function () {
				_this5.$acnfNotify.error('Usuário ou senha incorretos!!!');
			});
		}
	}]);

	return LoginController;
}(AcnfController);

angular.module('acnf.controllers').controller('LoginController', LoginController);

var LoginModule = function () {
	function LoginModule($stateProvider) {
		_classCallCheck(this, LoginModule);

		$stateProvider.state('login', {
			url: '/login',
			templateUrl: 'app/login/login.html',
			controller: 'LoginController'
		});
	}

	_createClass(LoginModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new LoginModule($stateProvider);
		}
	}]);

	return LoginModule;
}();

angular.module('acnf.login', []).config(LoginModule.moduleFactory);

var VendasModule = function (_AcnfModule2) {
	_inherits(VendasModule, _AcnfModule2);

	function VendasModule($stateProvider, $acnfSidebarProvider) {
		_classCallCheck(this, VendasModule);

		var _this6 = _possibleConstructorReturn(this, (VendasModule.__proto__ || Object.getPrototypeOf(VendasModule)).call(this));

		_this6.$stateProvider = $stateProvider;

		_this6.setMainState('vendas', '/vendas', {
			sidebar: function sidebar($acnfSidebar) {
				var sidebar = [{ header: 'Vendas' }, { text: 'Notas Fiscais', href: 'notas-fiscais', icon: 'file-text-o' }];

				$acnfSidebar.setItems(sidebar);
				$acnfSidebar.setParent('vendas');
			}
		});

		// NOTAS FISCAIS
		_this6.states.push({
			name: 'vendas.notasFiscais',
			url: '/notas-fiscais',
			templateUrl: 'app/vendas/notas-fiscais/notas-fiscais.html',
			controller: 'VendasNotasFiscaisController',
			roles: ['logged', 'consultar_lista_empresas']
		});

		_this6.states.push({
			name: 'vendas.notasFiscais.nova',
			url: '/nova',
			templateUrl: 'app/vendas/notas-fiscais/notas-fiscais-administrar.html',
			controller: 'VendasNotasFiscaisAdministrarController',
			roles: ['logged']
		});

		_this6.states.push({
			name: 'vendas.notasFiscais.editar',
			url: '/editar/:id',
			templateUrl: 'app/vendas/notas-fiscais/notas-fiscais-administrar.html',
			controller: 'VendasNotasFiscaisAdministrarController',
			roles: ['logged']
		});

		_this6.setStates();
		return _this6;
	}

	_createClass(VendasModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider, $acnfSidebarProvider) {
			return new VendasModule($stateProvider, $acnfSidebarProvider);
		}
	}]);

	return VendasModule;
}(AcnfModule);

angular.module('acnf.vendas', []).config(VendasModule.moduleFactory);

var CadastrosClientesAdministrarController = function (_AcnfController3) {
	CadastrosClientesAdministrarController.$inject = ["$scope", "$stateParams", "$acnfNotify", "$location", "$rootScope", "Clientes", "listaMunicipios", "listaEstados", "listaTipoPessoa", "listaContribuinte", "listaCodigoRegimeTributario", "listaSituacao"];
	_inherits(CadastrosClientesAdministrarController, _AcnfController3);

	function CadastrosClientesAdministrarController($scope, $stateParams, $acnfNotify, $location, $rootScope, Clientes, listaMunicipios, listaEstados, listaTipoPessoa, listaContribuinte, listaCodigoRegimeTributario, listaSituacao) {
		_classCallCheck(this, CadastrosClientesAdministrarController);

		var _this7 = _possibleConstructorReturn(this, (CadastrosClientesAdministrarController.__proto__ || Object.getPrototypeOf(CadastrosClientesAdministrarController)).call(this));

		_this7.$scope = $scope;
		_this7.$stateParams = $stateParams;
		_this7.$acnfNotify = $acnfNotify;
		_this7.$location = $location;
		_this7.$rootScope = $rootScope;
		_this7.Clientes = Clientes;

		// Listas de combos
		_this7.$scope.listaEstados = listaEstados.query();
		_this7.$scope.listaTipoPessoa = listaTipoPessoa.query();
		_this7.$scope.listaContribuinte = listaContribuinte.query();
		_this7.$scope.listaCodigoRegimeTributario = listaCodigoRegimeTributario.query();
		_this7.$scope.listaSituacao = listaSituacao.query();

		_this7.$scope.isLoadingMunicipios = true;

		if (_this7.$stateParams.id) {
			_this7.$scope.isLoading = true;

			var promise = _this7.Clientes.get({ idCliente: $stateParams.id }).$promise;

			promise.then(function (response) {
				_this7.$scope.entity = response;

				if (_this7.$scope.entity && _this7.$scope.entity.idEnumEstado) {
					var selected = listaEstados.get(_this7.$scope.entity.idEnumEstado);
					_this7.$scope.selectedUF = selected.sigla.toUpperCase();
				}
			}).finally(function () {
				_this7.$scope.isLoading = false;
			});
		} else {
			_this7.$scope.entity = new _this7.Clientes();
		}

		_this7.$rootScope.$watch('activePill', function (value) {
			_this7.$scope.active = value;
		});

		// Eventos de Busca de CEP
		_this7.$scope.$on('cep.loaded', function (event, params) {
			var data = params.data;

			if (!data.erro) {
				_this7.municipioFromCep = parseInt(data.ibge, 10);
				_this7.$scope.entity.idEnumEstado = data.idEnumEstado;
				_this7.$scope.entity.endereco = data.logradouro;
				_this7.$scope.entity.bairro = data.bairro;
				_this7.$scope.entity.complemento = data.complemento;
			}
		});

		_this7.$scope.$on('cep.loading', function (event, params) {
			if (params.loading) {
				_this7.$scope.entity.idEnumEstado = null;
				_this7.$scope.entity.endereco = null;
				_this7.$scope.entity.bairro = null;
				_this7.$scope.entity.complemento = null;
			}

			_this7.$scope.isLoadingCep = params.loading;
		});

		_this7.$scope.$on('municipios.loaded', function () {
			if (_this7.municipioFromCep) {
				_this7.$scope.entity.idEnumMunicipio = _this7.municipioFromCep;
			}
		});

		_this7.init();
		return _this7;
	}

	_createClass(CadastrosClientesAdministrarController, [{
		key: 'salvar',
		value: function salvar() {
			var _this8 = this;

			if (this.$scope.formClientes.$invalid) {
				return;
			}

			this.$scope.isLoading = true;

			if (this.$stateParams.id) {
				var promise = this.Clientes.update(this.$scope.entity).$promise;

				promise.then(function () {
					_this8.$acnfNotify.success('Cliente alterado com sucesso!!!');
				}).finally(function () {
					_this8.$scope.isLoading = false;
				});
			} else {
				this.$scope.entity.$save().then(function () {
					_this8.$acnfNotify.success('Cliente salvo com sucesso!!!');
				}).finally(function () {
					_this8.$scope.isLoading = false;
				});
			}
		}
	}]);

	return CadastrosClientesAdministrarController;
}(AcnfController);

angular.module('acnf.controllers').controller('CadastrosClientesAdministrarController', CadastrosClientesAdministrarController);

var CadastrosClientesController = function () {
	CadastrosClientesController.$inject = ["$scope", "$acnfNotify", "Clientes"];
	function CadastrosClientesController($scope, $acnfNotify, Clientes) {
		var _this9 = this;

		_classCallCheck(this, CadastrosClientesController);

		this.$scope = $scope;
		this.$acnfNotify = $acnfNotify;

		this.Clientes = Clientes;
		this.list();

		var link = function link(rowRecord) {
			_this9.delete(_this9, rowRecord);
		};

		this.$scope.rowMenu = [{ icon: 'trash', text: 'Excluir', action: link }];
	}

	_createClass(CadastrosClientesController, [{
		key: 'list',
		value: function list() {
			var _this10 = this;

			this.$scope.isLoading = true;

			var promise = this.Clientes.query({}).$promise;

			promise.then(function (response) {
				_this10.$scope.items = response;
			}).finally(function () {
				_this10.$scope.isLoading = false;
			});
		}
	}, {
		key: 'delete',
		value: function _delete(self, rowRecord) {
			if (angular.isDefined(rowRecord) && rowRecord.idCliente) {
				var promise = self.Clientes.delete({ idCliente: rowRecord.idCliente }).$promise;

				promise.then(function () {
					self.list();
					self.$acnfNotify.success('Cliente excluido com sucesso.');
				}).catch(function () {
					self.$acnfNotify.error('Erro.');
				});
			}
		}
	}]);

	return CadastrosClientesController;
}();

angular.module('acnf.controllers').controller('CadastrosClientesController', CadastrosClientesController);

var CadastrosProdutosAdministrarController = function (_AcnfController4) {
	CadastrosProdutosAdministrarController.$inject = ["$scope", "$stateParams", "listaOrigem", "Produtos", "$acnfNotify"];
	_inherits(CadastrosProdutosAdministrarController, _AcnfController4);

	function CadastrosProdutosAdministrarController($scope, $stateParams, listaOrigem, Produtos, $acnfNotify) {
		_classCallCheck(this, CadastrosProdutosAdministrarController);

		var _this11 = _possibleConstructorReturn(this, (CadastrosProdutosAdministrarController.__proto__ || Object.getPrototypeOf(CadastrosProdutosAdministrarController)).call(this));

		_this11.$scope = $scope;
		_this11.$stateParams = $stateParams;
		_this11.$acnfNotify = $acnfNotify;
		_this11.Produtos = Produtos;

		_this11.$scope.listaOrigem = listaOrigem.query();

		if (_this11.$stateParams.id) {
			_this11.$scope.isLoading = true;

			var promise = _this11.Produtos.get({ idNfeDet: $stateParams.id }).$promise;

			promise.then(function (response) {
				_this11.$scope.entity = response;
			}).finally(function () {
				_this11.$scope.isLoading = false;
			});
		}

		_this11.init();
		return _this11;
	}

	_createClass(CadastrosProdutosAdministrarController, [{
		key: 'salvar',
		value: function salvar() {
			var _this12 = this;

			if (this.$stateParams.id) {
				this.Produtos.update(this.$scope.entity, function () {
					_this12.$acnfNotify.success('Produto alterado com sucesso!!!');
				});
			} else {
				this.$scope.$entity.$save(function () {
					_this12.$acnfNotify.success('Produto salvo com sucesso!!!');
				});
			}
		}
	}]);

	return CadastrosProdutosAdministrarController;
}(AcnfController);

angular.module('acnf.controllers').controller('CadastrosProdutosAdministrarController', CadastrosProdutosAdministrarController);

var CadastrosProdutosController = function CadastrosProdutosController($scope, Produtos, $acnfNotify) {
	var _this13 = this;

	_classCallCheck(this, CadastrosProdutosController);

	this.$scope = $scope;

	this.$scope.isLoading = true;

	Produtos.query({}, function (response) {
		_this13.$scope.items = response;
		_this13.$scope.isLoading = false;
	}, function (response) {
		$acnfNotify.error('Erro ao buscar produtos...');
	});

	var test = function test(row) {
		console.log(row);
	};

	this.$scope.rowMenu = [{ icon: 'trash', text: 'Excluir', action: test }];
};
CadastrosProdutosController.$inject = ["$scope", "Produtos", "$acnfNotify"];

angular.module('acnf.controllers').controller('CadastrosProdutosController', CadastrosProdutosController);

var VendasNotasFiscaisAdministrarController = function (_AcnfController5) {
	VendasNotasFiscaisAdministrarController.$inject = ["$scope", "$stateParams", "$acnfNotify", "$location", "$rootScope", "Clientes", "listaMunicipios", "listaEstados", "listaTipoPessoa", "listaContribuinte", "listaCodigoRegimeTributario", "listaSituacao"];
	_inherits(VendasNotasFiscaisAdministrarController, _AcnfController5);

	function VendasNotasFiscaisAdministrarController($scope, $stateParams, $acnfNotify, $location, $rootScope, Clientes, listaMunicipios, listaEstados, listaTipoPessoa, listaContribuinte, listaCodigoRegimeTributario, listaSituacao) {
		_classCallCheck(this, VendasNotasFiscaisAdministrarController);

		var _this14 = _possibleConstructorReturn(this, (VendasNotasFiscaisAdministrarController.__proto__ || Object.getPrototypeOf(VendasNotasFiscaisAdministrarController)).call(this));

		_this14.$scope = $scope;
		_this14.$stateParams = $stateParams;
		_this14.$acnfNotify = $acnfNotify;
		_this14.$location = $location;
		_this14.$rootScope = $rootScope;
		_this14.Clientes = Clientes;

		// Listas de combos
		_this14.$scope.listaEstados = listaEstados.query();
		_this14.$scope.listaTipoPessoa = listaTipoPessoa.query();
		_this14.$scope.listaContribuinte = listaContribuinte.query();
		_this14.$scope.listaCodigoRegimeTributario = listaCodigoRegimeTributario.query();
		_this14.$scope.listaSituacao = listaSituacao.query();

		_this14.$scope.isLoadingMunicipios = true;

		if (_this14.$stateParams.id) {
			_this14.$scope.isLoading = true;

			var promise = _this14.Clientes.get({ idCliente: $stateParams.id }).$promise;

			promise.then(function (response) {
				_this14.$scope.entity = response;

				if (_this14.$scope.entity && _this14.$scope.entity.idEnumEstado) {
					var selected = listaEstados.get(_this14.$scope.entity.idEnumEstado);
					_this14.$scope.selectedUF = selected.sigla.toUpperCase();
				}
			}).finally(function () {
				_this14.$scope.isLoading = false;
			});
		} else {
			_this14.$scope.entity = new _this14.Clientes();
		}

		_this14.$rootScope.$watch('activePill', function (value) {
			_this14.$scope.active = value;
		});

		// Eventos de Busca de CEP
		_this14.$scope.$on('cep.loaded', function (event, params) {
			var data = params.data;

			if (!data.erro) {
				_this14.municipioFromCep = parseInt(data.ibge, 10);
				_this14.$scope.entity.idEnumEstado = data.idEnumEstado;
				_this14.$scope.entity.endereco = data.logradouro;
				_this14.$scope.entity.bairro = data.bairro;
				_this14.$scope.entity.complemento = data.complemento;
			}
		});

		_this14.$scope.$on('cep.loading', function (event, params) {
			if (params.loading) {
				_this14.$scope.entity.idEnumEstado = null;
				_this14.$scope.entity.endereco = null;
				_this14.$scope.entity.bairro = null;
				_this14.$scope.entity.complemento = null;
			}

			_this14.$scope.isLoadingCep = params.loading;
		});

		_this14.$scope.$on('municipios.loaded', function () {
			if (_this14.municipioFromCep) {
				_this14.$scope.entity.idEnumMunicipio = _this14.municipioFromCep;
			}
		});

		_this14.init();
		return _this14;
	}

	_createClass(VendasNotasFiscaisAdministrarController, [{
		key: 'salvar',
		value: function salvar() {
			var _this15 = this;

			if (this.$scope.formClientes.$invalid) {
				return;
			}

			this.$scope.isLoading = true;

			if (this.$stateParams.id) {
				var promise = this.Clientes.update(this.$scope.entity).$promise;

				promise.then(function () {
					_this15.$acnfNotify.success('Cliente alterado com sucesso!!!');
				}).finally(function () {
					_this15.$scope.isLoading = false;
				});
			} else {
				this.$scope.entity.$save().then(function () {
					_this15.$acnfNotify.success('Cliente salvo com sucesso!!!');
				}).finally(function () {
					_this15.$scope.isLoading = false;
				});
			}
		}
	}]);

	return VendasNotasFiscaisAdministrarController;
}(AcnfController);

angular.module('acnf.controllers').controller('VendasNotasFiscaisAdministrarController', VendasNotasFiscaisAdministrarController);

var VendasNotasFiscaisController = function () {
	VendasNotasFiscaisController.$inject = ["$scope", "$acnfNotify", "Nfe"];
	function VendasNotasFiscaisController($scope, $acnfNotify, Nfe) {
		var _this16 = this;

		_classCallCheck(this, VendasNotasFiscaisController);

		this.$scope = $scope;
		this.$acnfNotify = $acnfNotify;

		this.Nfe = Nfe;
		this.list();

		var link = function link(rowRecord) {
			_this16.delete(_this16, rowRecord);
		};

		this.$scope.rowMenu = [{ icon: 'trash', text: 'Excluir', action: link }];
	}

	_createClass(VendasNotasFiscaisController, [{
		key: 'list',
		value: function list() {
			var _this17 = this;

			this.$scope.isLoading = true;

			var promise = this.Nfe.query({}).$promise;

			promise.then(function (response) {
				_this17.$scope.items = response;
			}).finally(function () {
				_this17.$scope.isLoading = false;
			});
		}
	}, {
		key: 'delete',
		value: function _delete(self, rowRecord) {
			if (angular.isDefined(rowRecord) && rowRecord.id) {
				var promise = self.Nfe.delete({ id: rowRecord.id }).$promise;

				promise.then(function () {
					self.list();
					self.$acnfNotify.success('Nota Fiscal excluida com sucesso.');
				}).catch(function () {
					self.$acnfNotify.error('Erro.');
				});
			}
		}
	}]);

	return VendasNotasFiscaisController;
}();

angular.module('acnf.controllers').controller('VendasNotasFiscaisController', VendasNotasFiscaisController);

var AcnfApp = function (_AcnfComponent) {
	_inherits(AcnfApp, _AcnfComponent);

	function AcnfApp() {
		_classCallCheck(this, AcnfApp);

		var _this18 = _possibleConstructorReturn(this, (AcnfApp.__proto__ || Object.getPrototypeOf(AcnfApp)).call(this));

		_this18.templateUrl = 'app/app.html';
		return _this18;
	}

	_createClass(AcnfApp, null, [{
		key: 'directiveFactory',
		value: function directiveFactory() {
			return new AcnfApp();
		}
	}]);

	return AcnfApp;
}(AcnfComponent);

angular.module('acnf.components').directive('acnfApp', AcnfApp.directiveFactory);
(function () {
	'use strict';

	angular.module('acnf.common', []);

	// TODO: Check better place to this filter
	angular.module('acnf.common').filter('propsFilter', function () {
		return function (items, props) {
			var out = [];

			if (angular.isArray(items)) {
				(function () {
					var keys = Object.keys(props);

					items.forEach(function (item) {
						var itemMatches = false;

						for (var i = 0; i < keys.length; i++) {
							var prop = keys[i];
							var text = props[prop].toLowerCase();

							if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
								itemMatches = true;
								break;
							}
						}

						if (itemMatches) {
							out.push(item);
						}
					});
				})();
			} else {
				// Let the output be the input untouched
				out = items;
			}

			return out;
		};
	});
})();

(function () {
	// Generic query and get methods
	var _query = function _query(list) {
		return list;
	};

	function _get(list, value, field) {
		for (var i = 0, n = list.length; i < n; i++) {
			var comparator = field ? list[i][field] : list[i].id;

			if (comparator === value) {
				return list[i];
			}
		}
	}

	angular.module('acnf.common').service('listaEstados', function () {
		var list = [{ id: 0, sigla: 'TD', descricao: 'Todos' }, { id: 11, sigla: 'RO', descricao: 'Rondônia' }, { id: 12, sigla: 'AC', descricao: 'Acre' }, { id: 13, sigla: 'AM', descricao: 'Amazonas' }, { id: 14, sigla: 'RR', descricao: 'Roraima' }, { id: 15, sigla: 'PA', descricao: 'Pará' }, { id: 16, sigla: 'AP', descricao: 'Amapá' }, { id: 17, sigla: 'TO', descricao: 'Tocantis' }, { id: 21, sigla: 'MA', descricao: 'Maranhão' }, { id: 22, sigla: 'PI', descricao: 'Piauí' }, { id: 23, sigla: 'CE', descricao: 'Ceará' }, { id: 24, sigla: 'RN', descricao: 'Rio Grande do Norte' }, { id: 25, sigla: 'PB', descricao: 'Paraíba' }, { id: 26, sigla: 'PE', descricao: 'Pernambuco' }, { id: 27, sigla: 'AL', descricao: 'Alagoas' }, { id: 28, sigla: 'SE', descricao: 'Sergipe' }, { id: 29, sigla: 'BA', descricao: 'Bahia' }, { id: 31, sigla: 'MG', descricao: 'Minas Gerais' }, { id: 32, sigla: 'ES', descricao: 'Espírito Santo' }, { id: 33, sigla: 'RJ', descricao: 'Rio de Janeiro' }, { id: 35, sigla: 'SP', descricao: 'São Paulo' }, { id: 41, sigla: 'PR', descricao: 'Paraná' }, { id: 42, sigla: 'SC', descricao: 'Santa Catarina' }, { id: 43, sigla: 'RS', descricao: 'Rio Grande do Sul' }, { id: 50, sigla: 'MS', descricao: 'Mato Grosso do Sul' }, { id: 51, sigla: 'MT', descricao: 'Mato Grosso' }, { id: 52, sigla: 'GO', descricao: 'Goiás' }, { id: 53, sigla: 'DF', descricao: 'Distrito Federal' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			},
			getBySigla: function getBySigla(sigla) {
				return _get(list, sigla, 'sigla');
			}
		};
	});

	angular.module('acnf.common').service('listaMunicipios', ["$q", "$acnfNotify", "MunicipiosEstado", function ($q, $acnfNotify, MunicipiosEstado) {
		return {
			query: function query(idEnumMunicipio) {
				var deferred = $q.defer();
				var promise = MunicipiosEstado.query({ idEnumMunicipio: idEnumMunicipio }).$promise;

				promise.then(function (response) {
					deferred.resolve(response);
				}).catch(function (response) {
					deferred.reject(response);
					$acnfNotify.error('Ocorreu um erro ao buscar as cidades.');
				});

				return deferred.promise;
			}
		};
	}]);

	angular.module('acnf.common').service('listaTipoPessoa', function () {
		var list = [{ id: 0, descricao: 'Pessoa Física' }, { id: 1, descricao: 'Pessoa Jurídica' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaCodigoRegimeTributario', function () {
		var list = [{ id: 0, descricao: 'Simples Nacional' }, { id: 1, descricao: 'Regime Normal' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('buscaCep', ["$q", "$acnfNotify", "Cep", function ($q, $acnfNotify, Cep) {
		return {
			get: function get(cep) {
				var deferred = $q.defer();
				var promise = Cep.get({ cep: cep }).$promise;

				promise.then(function (response) {
					if (response.erro) {
						deferred.reject(response);
						$acnfNotify.error('Erro ao buscar o CEP. Tente novamente.');
					} else {
						deferred.resolve(response);
					}
				});

				return deferred.promise;
			}
		};
	}]);

	angular.module('acnf.common').service('listaContribuinte', function () {
		var list = [{ id: 1, descricao: 'Contribuinte de ICMS' }, { id: 2, descricao: 'Contribuinte isento' }, { id: 9, descricao: 'Não Contribuinte, que pode ou não possuir Inscrição Estadual no Cadastro de Contribuintes do ICMS' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaTipoEmissao', function () {
		var list = [{ id: 0, descricao: 'Emissão Normal' }, { id: 1, descricao: 'Contingência FS-IA, com impressão do DANFE em' }, { id: 2, descricao: 'Contingência SCAN (Sistema de Contingência do' }, { id: 3, descricao: 'Contingência DPEC (Declaração Prévia da Emiss' }, { id: 4, descricao: 'Contingência FS-DA, com impressão do DANFE em' }, { id: 5, descricao: 'Contingência SVC-AN (SEFAZ Virtual de Conting' }, { id: 6, descricao: 'Contingência SVC-RS (SEFAZ Virtual de Conting' }, { id: 8, descricao: 'Contingência off-line da NFC-e' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaRegimeTributario', function () {
		var list = [{ id: 1, descricao: 'Regime Normal' }, { id: 2, descricao: 'Simples Nacional' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaSituacao', function () {
		var list = [{ id: 'A', descricao: 'Ativo' }, { id: 'I', descricao: 'Inativo' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaOrigem', function () {
		var list = [{ id: 0, descricao: 'Nacional, exceto as indicadas nos códigos 3, 4, 5 e 8;' }, { id: 1, descricao: 'Estrangeira - Importação direta, exceto a indicada no código 6' }, { id: 2, descricao: 'Estrangeira - Adquirida no mercado interno, exceto a indicada no código 7' }, { id: 3, descricao: 'Nacional, mercadoria ou bem com Conteúdo de Importação superior a 40% e inferior ou igual a 70%' }, { id: 4, descricao: 'Nacional, cuja produção tenha sido feita em conformidade com os processos produtivos básicos de que tratam as legislações citadas nos Ajustes' }, { id: 5, descricao: 'Nacional, mercadoria ou bem com Conteúdo de Importação inferior ou igual a 40%' }, { id: 6, descricao: 'Estrangeira - Importação direta, sem similar nacional, constante em lista da CAMEX e gás natural' }, { id: 7, descricao: 'Estrangeira - Adquirida no mercado interno, sem similar nacional, constante em lista da CAMEX e gás natural' }, { id: 8, descricao: 'Nacional, mercadoria ou bem com Conteúdo de Importação superior a 70%' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});
})();
(function () {
	angular.module('acnf.common').factory('Cep', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.cepApi + '/ws/:cep/json', { cep: '@cep' }, {});
	}]);

	angular.module('acnf.common').factory('Login', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/auth/usuario/:_id', { _id: '@_id' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Empresas', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/empresas/:idEmpresa', { idEmpresa: '@idEmpresa' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Clientes', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/clientes/:idCliente', { idCliente: '@idCliente' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Produtos', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/produtos/:idNfeDet', { idNfeDet: '@idNfeDet' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('MunicipiosEstado', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/estados/:idEnumMunicipio/municipios', { idEnumMunicipio: '@idEnumMunicipio' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Nfe', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/nfe/:id', { id: '@id' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);
})();

var AcnfComboCodigoRegimeTributario = function (_AcnfComponent2) {
	_inherits(AcnfComboCodigoRegimeTributario, _AcnfComponent2);

	function AcnfComboCodigoRegimeTributario(listaCodigoRegimeTributario) {
		_classCallCheck(this, AcnfComboCodigoRegimeTributario);

		var _this19 = _possibleConstructorReturn(this, (AcnfComboCodigoRegimeTributario.__proto__ || Object.getPrototypeOf(AcnfComboCodigoRegimeTributario)).call(this));

		_this19.restrict = 'E';
		_this19.templateUrl = 'components/comboCodigoRegimeTributario/comboCodigoRegimeTributario.html';

		_this19.listaCodigoRegimeTributario = listaCodigoRegimeTributario;
		_this19.scope = {
			ngModel: '=',
			required: '@'
		};
		return _this19;
	}

	_createClass(AcnfComboCodigoRegimeTributario, [{
		key: 'linkComponent',
		value: function linkComponent(scope) {
			scope.listaCodigoRegimeTributario = this.listaCodigoRegimeTributario.query();
		}
	}], [{
		key: 'directiveFactory',
		value: ["listaCodigoRegimeTributario", function directiveFactory(listaCodigoRegimeTributario) {
			"ngInject";

			AcnfComboCodigoRegimeTributario.instance = new AcnfComboCodigoRegimeTributario(listaCodigoRegimeTributario);
			return AcnfComboCodigoRegimeTributario.instance;
		}]
	}]);

	return AcnfComboCodigoRegimeTributario;
}(AcnfComponent);

angular.module('acnf.components').directive('acnfComboCodigoRegimeTributario', AcnfComboCodigoRegimeTributario.directiveFactory);

var AcnfComboMunicipios = function (_AcnfComponent3) {
	_inherits(AcnfComboMunicipios, _AcnfComponent3);

	function AcnfComboMunicipios(listaMunicipios, $rootScope) {
		_classCallCheck(this, AcnfComboMunicipios);

		var _this20 = _possibleConstructorReturn(this, (AcnfComboMunicipios.__proto__ || Object.getPrototypeOf(AcnfComboMunicipios)).call(this));

		_this20.restrict = 'E';
		_this20.templateUrl = 'components/comboMunicipios/comboMunicipios.html';
		_this20.$rootScope = $rootScope;

		_this20.listaMunicipios = listaMunicipios;
		_this20.scope = {
			entity: '=',
			required: '@'
		};
		return _this20;
	}

	_createClass(AcnfComboMunicipios, [{
		key: 'linkComponent',
		value: function linkComponent($scope, $element, $attributes) {
			var _this21 = this;

			$scope.$watch('entity.idEnumEstado', function (newValue, oldValue) {
				if (angular.isDefined(newValue) && newValue !== null) {
					$scope.isLoadingMunicipios = true;

					var isDefined = angular.isDefined;

					if (isDefined(newValue) && isDefined(oldValue) && newValue !== oldValue) {
						$scope.entity.idEnumMunicipio = null;
						$scope.placeholderMunicipios = null;
					}

					if ($scope.entity && isDefined($scope.entity.idEnumEstado)) {
						_this21.listaMunicipios.query($scope.entity.idEnumEstado).then(function (response) {
							$scope.placeholderMunicipios = 'Selecione a Cidade...';
							$scope.isLoadingMunicipios = false;
							$scope.listaMunicipios = response;
							_this21.$rootScope.$broadcast('municipios.loaded');
						});
					}
				}
			});
		}
	}], [{
		key: 'directiveFactory',
		value: ["listaMunicipios", "$rootScope", function directiveFactory(listaMunicipios, $rootScope) {
			"ngInject";

			AcnfComboMunicipios.instance = new AcnfComboMunicipios(listaMunicipios, $rootScope);
			return AcnfComboMunicipios.instance;
		}]
	}]);

	return AcnfComboMunicipios;
}(AcnfComponent);

angular.module('acnf.components').directive('acnfComboMunicipios', AcnfComboMunicipios.directiveFactory);

var AcnfComboTipoPessoa = function (_AcnfComponent4) {
	_inherits(AcnfComboTipoPessoa, _AcnfComponent4);

	function AcnfComboTipoPessoa(listaTipoPessoa, $rootScope) {
		_classCallCheck(this, AcnfComboTipoPessoa);

		var _this22 = _possibleConstructorReturn(this, (AcnfComboTipoPessoa.__proto__ || Object.getPrototypeOf(AcnfComboTipoPessoa)).call(this));

		_this22.restrict = 'E';
		_this22.templateUrl = 'components/comboTipoPessoa/comboTipoPessoa.html';

		_this22.listaTipoPessoa = listaTipoPessoa;
		_this22.scope = {
			ngModel: '=',
			required: '@'
		};
		return _this22;
	}

	_createClass(AcnfComboTipoPessoa, [{
		key: 'linkComponent',
		value: function linkComponent(scope) {
			scope.listaTipoPessoa = this.listaTipoPessoa.query();
		}
	}], [{
		key: 'directiveFactory',
		value: ["listaTipoPessoa", function directiveFactory(listaTipoPessoa) {
			"ngInject";

			AcnfComboTipoPessoa.instance = new AcnfComboTipoPessoa(listaTipoPessoa);
			return AcnfComboTipoPessoa.instance;
		}]
	}]);

	return AcnfComboTipoPessoa;
}(AcnfComponent);

angular.module('acnf.components').directive('acnfComboTipoPessoa', AcnfComboTipoPessoa.directiveFactory);

var AcnfInputCep = function (_AcnfComponent5) {
	_inherits(AcnfInputCep, _AcnfComponent5);

	function AcnfInputCep(buscaCep, $rootScope, listaEstados) {
		_classCallCheck(this, AcnfInputCep);

		var _this23 = _possibleConstructorReturn(this, (AcnfInputCep.__proto__ || Object.getPrototypeOf(AcnfInputCep)).call(this));

		_this23.restrict = 'E';
		_this23.templateUrl = 'components/inputCep/inputCep.html';
		_this23.require = 'ngModel';
		_this23.$rootScope = $rootScope;

		_this23.buscaCep = buscaCep;
		_this23.listaEstados = listaEstados;

		_this23.scope = {
			ngModel: '=',
			ngRequired: '=',
			required: '='
		};
		return _this23;
	}

	_createClass(AcnfInputCep, [{
		key: 'linkComponent',
		value: function linkComponent($scope, $element, $attributes, $ctrl) {
			this.$scope = $scope;

			$ctrl.$parsers.push(function (value) {
				if (!value) {
					return value ? Number(value.replace(new RegExp('[(),.:/ -]', 'g'), '')) : null;
				}
			});
		}
	}, {
		key: 'changeCep',
		value: function changeCep(self) {
			var _this24 = this;

			if (angular.isDefined(self.ngModel) && self.ngModel.length === 8) {
				this.$scope.isLoading = true;
				this.$rootScope.$broadcast('cep.loading', { loading: true });

				this.buscaCep.get(self.ngModel).then(function (response) {
					if (angular.isDefined(response.uf)) {
						var estado = _this24.listaEstados.getBySigla(response.uf);
						response.idEnumEstado = estado.id;
					}

					_this24.$rootScope.$broadcast('cep.loaded', { data: response });
				}).finally(function () {
					_this24.$rootScope.$broadcast('cep.loading', { loading: false });
					_this24.$scope.isLoading = false;
				});
			}
		}
	}], [{
		key: 'directiveFactory',
		value: ["buscaCep", "$rootScope", "listaEstados", function directiveFactory(buscaCep, $rootScope, listaEstados) {
			"ngInject";

			AcnfInputCep.instance = new AcnfInputCep(buscaCep, $rootScope, listaEstados);
			return AcnfInputCep.instance;
		}]
	}]);

	return AcnfInputCep;
}(AcnfComponent);

angular.module('acnf.components').directive('acnfInputCep', AcnfInputCep.directiveFactory);