'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AcnfApp = function (_AcnfComponent) {
	_inherits(AcnfApp, _AcnfComponent);

	function AcnfApp() {
		_classCallCheck(this, AcnfApp);

		var _this = _possibleConstructorReturn(this, (AcnfApp.__proto__ || Object.getPrototypeOf(AcnfApp)).call(this));

		_this.templateUrl = 'app/app.html';
		return _this;
	}

	_createClass(AcnfApp, null, [{
		key: 'directiveFactory',
		value: function directiveFactory() {
			return new AcnfApp();
		}
	}]);

	return AcnfApp;
}(AcnfComponent);

angular.module('acnf.framework').directive('acnfApp', AcnfApp.directiveFactory);
angular.module('acnf.controllers', []);

var dependencies = ['acnf.framework', 'acnf.components', 'acnf.common', 'acnf.controllers', 'acnf.login', 'acnf.inicio', 'acnf.empresa', 'acnf.cadastros'];

angular.module('acnf', dependencies).run(["$acnfHeader", "$acnfSidebar", "$acnfSecurity", "$rootScope", "$acnfNavigation", "$localStorage", "$sessionStorage", "$location", "$acnfScroll", function ($acnfHeader, $acnfSidebar, $acnfSecurity, $rootScope, $acnfNavigation, $localStorage, $sessionStorage, $location, $acnfScroll) {
	"ngInject";

	$acnfHeader.setLogo('images/logo.png');

	$acnfHeader.setMenuItems([{ id: 'inicio', text: 'Início', href: '/inicio', icon: 'home' }]);

	$acnfNavigation.otherwise('inicio');

	var logged = $localStorage.logged || $sessionStorage.logged;

	if (logged && logged.roles) {
		$acnfSecurity.setRoles(logged.roles);
	}

	var checkLogin = function checkLogin(e, toState, toParams, fromState, fromParams) {
		if (toState.url === '/login' || $rootScope.logged) {
			return;
		}

		if (logged && toState) {
			$rootScope.header.logged = {
				name: logged.name
			};

			$rootScope.token = logged.token;
			$rootScope.logged = logged;
			$location.path(toState.url);
		} else {
			$location.path('/login');
		}
	};

	checkLogin(null, {});

	$rootScope.$on('$stateChangeStart', function (e, toState, toParams, fromState, fromParams) {
		checkLogin(e, toState, toParams, fromState, fromParams);
	});

	$rootScope.logout = function () {
		localStorage.clear();
		sessionStorage.clear();
		$rootScope.logged = null;

		$acnfSecurity.clear();
		$location.path('/login').replace();
	};
}]).config(["$httpProvider", function ($httpProvider) {
	$httpProvider.interceptors.push(["$rootScope", function ($rootScope) {
		return {
			'request': function request(config) {
				config.headers.Authorization = 'Basic ' + $rootScope.token;
				return config;
			}
		};
	}]);
}]).constant('$config', {
	api: 'http://host1.acnf.com.br:8080'
});

angular.element(document).ready(function () {
	angular.bootstrap(document, ['acnf']);
});

var CadastrosModule = function (_AcnfModule) {
	_inherits(CadastrosModule, _AcnfModule);

	function CadastrosModule($stateProvider, $acnfSidebarProvider) {
		_classCallCheck(this, CadastrosModule);

		var _this2 = _possibleConstructorReturn(this, (CadastrosModule.__proto__ || Object.getPrototypeOf(CadastrosModule)).call(this));

		_this2.$stateProvider = $stateProvider;

		_this2.setMainState('cadastros', '/cadastros', {
			sidebar: function sidebar($acnfSidebar) {
				var sidebar = [{ header: 'Cadastros' }, { text: 'Clientes', href: 'clientes', icon: 'user' }, { text: 'Produtos', href: 'produtos', icon: 'tags' }, { text: 'Relatórios', href: 'relatorios', icon: 'file-text-o' }, { text: 'Configurações', href: 'configuracoes', icon: 'cog' }];

				$acnfSidebar.setItems(sidebar);
				$acnfSidebar.setParent('cadastros');
			}
		});

		// CLIENTES
		_this2.states.push({
			name: 'cadastros.clientes',
			url: '/clientes',
			templateUrl: 'app/cadastros/clientes/clientes.html',
			controller: 'CadastrosClientesController',
			roles: ['logged', 'consultar_lista_empresas']
		});

		_this2.states.push({
			name: 'cadastros.clientes.novo',
			url: '/novo',
			templateUrl: 'app/cadastros/clientes/clientes-administrar.html',
			controller: 'CadastrosClientesAdministrarController',
			roles: ['logged']
		});

		_this2.states.push({
			name: 'cadastros.clientes.editar',
			url: '/editar/:id',
			templateUrl: 'app/cadastros/clientes/clientes-administrar.html',
			controller: 'CadastrosClientesAdministrarController',
			roles: ['logged']
		});

		// PRODUTOS
		_this2.states.push({
			name: 'cadastros.produtos',
			url: '/produtos',
			templateUrl: 'app/cadastros/produtos/produtos.html',
			controller: 'CadastrosProdutosController',
			roles: ['logged']
		});

		_this2.states.push({
			name: 'cadastros.produtos.novo',
			url: '/novo',
			templateUrl: 'app/cadastros/produtos/produtos-administrar.html',
			controller: 'CadastrosProdutosAdministrarController',
			roles: ['logged']
		});

		_this2.states.push({
			name: 'cadastros.produtos.editar',
			url: '/editar/:id',
			templateUrl: 'app/cadastros/produtos/produtos-administrar.html',
			controller: 'CadastrosProdutosAdministrarController',
			roles: ['logged']
		});

		_this2.setStates();
		return _this2;
	}

	_createClass(CadastrosModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider, $acnfSidebarProvider) {
			return new CadastrosModule($stateProvider, $acnfSidebarProvider);
		}
	}]);

	return CadastrosModule;
}(AcnfModule);

angular.module('acnf.cadastros', []).config(CadastrosModule.moduleFactory);

var EmpresaController = function (_AcnfController) {
	EmpresaController.$inject = ["$scope", "$acnfNotify", "$acnfSidebar", "$rootScope", "listaEstados", "listaTipoPessoa", "listaMunicipios", "Empresas"];
	_inherits(EmpresaController, _AcnfController);

	function EmpresaController($scope, $acnfNotify, $acnfSidebar, $rootScope, listaEstados, listaTipoPessoa, listaMunicipios, Empresas) {
		_classCallCheck(this, EmpresaController);

		var _this3 = _possibleConstructorReturn(this, (EmpresaController.__proto__ || Object.getPrototypeOf(EmpresaController)).call(this));

		_this3.$scope = $scope;
		_this3.$scope.isLoading = true;
		_this3.$scope.listaEstados = listaEstados.query();
		_this3.$scope.listaTipoPessoa = listaTipoPessoa.query();

		_this3.$acnfNotify = $acnfNotify;
		_this3.Empresas = Empresas;

		var promise = _this3.Empresas.get({ idEmpresa: $rootScope.logged.idEmpresa }).$promise;

		promise.then(function (response) {
			_this3.$scope.entity = response;

			if (_this3.$scope.entity && _this3.$scope.entity.idEnumEstado) {
				var selected = listaEstados.get(_this3.$scope.entity.idEnumEstado);
				_this3.$scope.selectedUF = selected.sigla.toUpperCase();
			}
		}).finally(function () {
			_this3.$scope.isLoading = false;
		});

		$acnfSidebar.setItems(null);

		_this3.init();
		return _this3;
	}

	_createClass(EmpresaController, [{
		key: 'salvar',
		value: function salvar() {
			var _this4 = this;

			if (this.$scope.formEmpresa && this.$scope.formEmpresa.$invalid) {
				return;
			}

			this.$scope.isLoading = true;

			var promise = this.Empresas.update(this.$scope.entity).$promise;
			promise.then(function () {
				_this4.$acnfNotify.success('Salvo com sucesso.');
			}, function () {
				_this4.$acnfNotify.error('Erro ao salvar.');
			}).finally(function () {
				_this4.$scope.isLoading = false;
			});
		}
	}]);

	return EmpresaController;
}(AcnfController);

angular.module('acnf.controllers').controller('EmpresaController', EmpresaController);

var EmpresaModule = function () {
	function EmpresaModule($stateProvider) {
		_classCallCheck(this, EmpresaModule);

		$stateProvider.state('empresa', {
			url: '/empresa',
			templateUrl: 'app/empresa/empresa.html',
			controller: 'EmpresaController'
		});
	}

	_createClass(EmpresaModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new EmpresaModule($stateProvider);
		}
	}]);

	return EmpresaModule;
}();

angular.module('acnf.empresa', []).config(EmpresaModule.moduleFactory);

var InicioController = function InicioController($scope, $acnfHeader, $acnfSidebar) {
	_classCallCheck(this, InicioController);

	this.$scope = $scope;

	$acnfSidebar.setItems(null);
};
InicioController.$inject = ["$scope", "$acnfHeader", "$acnfSidebar"];

angular.module('acnf.controllers').controller('InicioController', InicioController);

var InicioModule = function () {
	function InicioModule($stateProvider) {
		_classCallCheck(this, InicioModule);

		$stateProvider.state('inicio', {
			url: '/inicio',
			templateUrl: 'app/inicio/inicio.html',
			controller: 'InicioController as vm',
			roles: ['logged']
		});
	}

	_createClass(InicioModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new InicioModule($stateProvider);
		}
	}]);

	return InicioModule;
}();

angular.module('acnf.inicio', []).config(InicioModule.moduleFactory);

var LoginController = function (_AcnfController2) {
	LoginController.$inject = ["$scope", "$http", "$acnfSidebar", "$acnfNotify", "$acnfSecurity", "$localStorage", "$location", "$rootScope", "$sessionStorage", "$base64", "Login"];
	_inherits(LoginController, _AcnfController2);

	function LoginController($scope, $http, $acnfSidebar, $acnfNotify, $acnfSecurity, $localStorage, $location, $rootScope, $sessionStorage, $base64, Login) {
		_classCallCheck(this, LoginController);

		var _this5 = _possibleConstructorReturn(this, (LoginController.__proto__ || Object.getPrototypeOf(LoginController)).call(this));

		_this5.$scope = $scope;
		_this5.$http = $http;
		_this5.$localStorage = $localStorage;
		_this5.$sessionStorage = $sessionStorage;
		_this5.$location = $location;
		_this5.$rootScope = $rootScope;
		_this5.$base64 = $base64;
		_this5.$acnfNotify = $acnfNotify;
		_this5.$acnfSecurity = $acnfSecurity;
		_this5.Login = Login;

		$acnfSidebar.setItems(null);

		_this5.init();

		var params = $location.search();
		if (params.usuario && params.senha) {
			_this5.$scope.entity = {};
			_this5.$scope.entity.usuario = params.usuario;
			_this5.$scope.entity.senha = params.senha;

			_this5.login();
		}
		return _this5;
	}

	_createClass(LoginController, [{
		key: 'login',
		value: function login() {
			var _this6 = this;

			if (this.$scope.formLogin && this.$scope.formLogin.$invalid) {
				return;
			}

			var userHash = this.$base64.encode(this.$scope.entity.usuario + ':' + this.$scope.entity.senha);
			this.$rootScope.token = userHash;

			this.Login.get({}, function (response) {
				var storage = _this6.$scope.entity.lembrar ? _this6.$localStorage : _this6.$sessionStorage;

				var roles = ['logged'];

				if (response.permissoes) {
					roles = roles.concat(response.permissoes);
				}

				_this6.$acnfSecurity.setRoles(roles);

				storage.logged = {
					idEmpresa: response.idEmpresa,
					name: response.username,
					roles: roles,
					token: _this6.$rootScope.token
				};

				_this6.$rootScope.header.logged = {
					name: response.username
				};

				_this6.$rootScope.logged = storage.logged;
				_this6.$location.search({});
				_this6.$location.path('/inicio').replace();
			}, function () {
				_this6.$acnfNotify.error('Usuário ou senha incorretos!!!');
			});
		}
	}]);

	return LoginController;
}(AcnfController);

angular.module('acnf.controllers').controller('LoginController', LoginController);

var LoginModule = function () {
	function LoginModule($stateProvider) {
		_classCallCheck(this, LoginModule);

		$stateProvider.state('login', {
			url: '/login',
			templateUrl: 'app/login/login.html',
			controller: 'LoginController'
		});
	}

	_createClass(LoginModule, null, [{
		key: 'moduleFactory',
		value: function moduleFactory($stateProvider) {
			return new LoginModule($stateProvider);
		}
	}]);

	return LoginModule;
}();

angular.module('acnf.login', []).config(LoginModule.moduleFactory);

var CadastrosClientesAdministrarController = function (_AcnfController3) {
	CadastrosClientesAdministrarController.$inject = ["$scope", "$stateParams", "$acnfNotify", "$location", "Clientes", "listaMunicipios", "listaEstados", "listaTipoPessoa"];
	_inherits(CadastrosClientesAdministrarController, _AcnfController3);

	function CadastrosClientesAdministrarController($scope, $stateParams, $acnfNotify, $location, Clientes, listaMunicipios, listaEstados, listaTipoPessoa) {
		_classCallCheck(this, CadastrosClientesAdministrarController);

		var _this7 = _possibleConstructorReturn(this, (CadastrosClientesAdministrarController.__proto__ || Object.getPrototypeOf(CadastrosClientesAdministrarController)).call(this));

		_this7.$scope = $scope;
		_this7.$stateParams = $stateParams;
		_this7.$acnfNotify = $acnfNotify;
		_this7.$location = $location;
		_this7.Clientes = Clientes;
		_this7.$scope.listaEstados = listaEstados.query();
		_this7.$scope.listaTipoPessoa = listaTipoPessoa.query();
		_this7.$scope.isLoadingMunicipios = true;

		if (_this7.$stateParams.id) {
			_this7.$scope.isLoading = true;

			var promise = _this7.Clientes.get({ idCliente: $stateParams.id }).$promise;

			promise.then(function (response) {
				_this7.$scope.entity = response;

				if (_this7.$scope.entity && _this7.$scope.entity.idEnumEstado) {
					var selected = listaEstados.get(_this7.$scope.entity.idEnumEstado);
					_this7.$scope.selectedUF = selected.sigla.toUpperCase();
				}
			}).finally(function () {
				_this7.$scope.isLoading = false;
			});
		} else {
			_this7.$scope.entity = new _this7.Clientes();
		}

		_this7.$scope.$watch('entity.idEnumEstado', function (newValue, oldValue) {
			_this7.$scope.isLoadingMunicipios = true;

			var isDefined = angular.isDefined;

			if (isDefined(newValue) && isDefined(oldValue) && newValue !== oldValue) {
				_this7.$scope.entity.idEnumMunicipio = null;
				_this7.$scope.placeholderMunicipios = null;
			}

			if (_this7.$scope.entity && isDefined(_this7.$scope.entity.idEnumEstado)) {
				listaMunicipios.query(_this7.$scope.entity.idEnumEstado).then(function (response) {
					_this7.$scope.placeholderMunicipios = 'Selecione a Cidade...';
					_this7.$scope.isLoadingMunicipios = false;
					_this7.$scope.listaMunicipios = response;
				});
			}
		});

		_this7.init();
		return _this7;
	}

	_createClass(CadastrosClientesAdministrarController, [{
		key: 'salvar',
		value: function salvar() {
			var _this8 = this;

			if (this.$scope.formClientes.$invalid) {
				return;
			}

			this.$scope.isLoading = true;

			if (this.$stateParams.id) {
				var promise = this.Clientes.update(this.$scope.entity).$promise;

				promise.then(function () {
					_this8.$acnfNotify.success('Cliente alterado com sucesso!!!');
				}).finally(function () {
					_this8.$scope.isLoading = false;
				});
			} else {
				this.$scope.entity.$save().then(function () {
					_this8.$acnfNotify.success('Cliente salvo com sucesso!!!');
				}).finally(function () {
					_this8.$scope.isLoading = false;
				});
			}
		}
	}]);

	return CadastrosClientesAdministrarController;
}(AcnfController);

angular.module('acnf.controllers').controller('CadastrosClientesAdministrarController', CadastrosClientesAdministrarController);

var CadastrosClientesController = function () {
	CadastrosClientesController.$inject = ["$scope", "$acnfNotify", "Clientes"];
	function CadastrosClientesController($scope, $acnfNotify, Clientes) {
		var _this9 = this;

		_classCallCheck(this, CadastrosClientesController);

		this.$scope = $scope;
		this.$acnfNotify = $acnfNotify;

		this.Clientes = Clientes;
		this.list();

		var link = function link(rowRecord) {
			_this9.delete(_this9, rowRecord);
		};

		this.$scope.rowMenu = [{ icon: 'trash', text: 'Excluir', action: link }];
	}

	_createClass(CadastrosClientesController, [{
		key: 'list',
		value: function list() {
			var _this10 = this;

			this.$scope.isLoading = true;

			var promise = this.Clientes.query({}).$promise;

			promise.then(function (response) {
				_this10.$scope.items = response;
			}).finally(function () {
				_this10.$scope.isLoading = false;
			});
		}
	}, {
		key: 'delete',
		value: function _delete(self, rowRecord) {
			if (angular.isDefined(rowRecord) && rowRecord.idCliente) {
				var promise = self.Clientes.delete({ idCliente: rowRecord.idCliente }).$promise;

				promise.then(function () {
					self.list();
					self.$acnfNotify.success('Cliente excluido com sucesso.');
				}).catch(function () {
					self.$acnfNotify.error('Erro.');
				});
			}
		}
	}]);

	return CadastrosClientesController;
}();

angular.module('acnf.controllers').controller('CadastrosClientesController', CadastrosClientesController);

var CadastrosProdutosAdministrarController = function (_AcnfController4) {
	CadastrosProdutosAdministrarController.$inject = ["$scope", "$stateParams", "Produtos", "$acnfNotify"];
	_inherits(CadastrosProdutosAdministrarController, _AcnfController4);

	function CadastrosProdutosAdministrarController($scope, $stateParams, Produtos, $acnfNotify) {
		_classCallCheck(this, CadastrosProdutosAdministrarController);

		var _this11 = _possibleConstructorReturn(this, (CadastrosProdutosAdministrarController.__proto__ || Object.getPrototypeOf(CadastrosProdutosAdministrarController)).call(this));

		_this11.$scope = $scope;
		_this11.$stateParams = $stateParams;
		_this11.$acnfNotify = $acnfNotify;
		_this11.Produtos = Produtos;

		if (_this11.$stateParams.id) {
			_this11.$scope.isLoading = true;

			var promise = _this11.Produtos.get({ idNfeDet: $stateParams.id }).$promise;

			promise.then(function (response) {
				_this11.$scope.entity = response;
			}).finally(function () {
				_this11.$scope.isLoading = false;
			});
		}

		_this11.init();
		return _this11;
	}

	_createClass(CadastrosProdutosAdministrarController, [{
		key: 'salvar',
		value: function salvar() {
			var _this12 = this;

			if (this.$stateParams.id) {
				this.Produtos.update(this.$scope.entity, function () {
					_this12.$acnfNotify.success('Produto alterado com sucesso!!!');
				});
			} else {
				this.$scope.$entity.$save(function () {
					_this12.$acnfNotify.success('Produto salvo com sucesso!!!');
				});
			}
		}
	}]);

	return CadastrosProdutosAdministrarController;
}(AcnfController);

angular.module('acnf.controllers').controller('CadastrosProdutosAdministrarController', CadastrosProdutosAdministrarController);

var CadastrosProdutosController = function CadastrosProdutosController($scope, Produtos, $acnfNotify) {
	var _this13 = this;

	_classCallCheck(this, CadastrosProdutosController);

	this.$scope = $scope;

	this.$scope.isLoading = true;

	Produtos.query({}, function (response) {
		_this13.$scope.items = response;
		_this13.$scope.isLoading = false;
	}, function (response) {
		$acnfNotify.error('Erro ao buscar produtos...');
	});

	var test = function test(row) {
		console.log(row);
	};

	this.$scope.rowMenu = [{ icon: 'trash', text: 'Excluir', action: test }];
};
CadastrosProdutosController.$inject = ["$scope", "Produtos", "$acnfNotify"];

angular.module('acnf.controllers').controller('CadastrosProdutosController', CadastrosProdutosController);
(function () {
	'use strict';

	angular.module('acnf.common', []);

	// TODO: Check better place to this filter
	angular.module('acnf.common').filter('propsFilter', function () {
		return function (items, props) {
			var out = [];

			if (angular.isArray(items)) {
				(function () {
					var keys = Object.keys(props);

					items.forEach(function (item) {
						var itemMatches = false;

						for (var i = 0; i < keys.length; i++) {
							var prop = keys[i];
							var text = props[prop].toLowerCase();

							if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
								itemMatches = true;
								break;
							}
						}

						if (itemMatches) {
							out.push(item);
						}
					});
				})();
			} else {
				// Let the output be the input untouched
				out = items;
			}

			return out;
		};
	});
})();

(function () {
	angular.module('acnf.common').factory('Login', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/auth/usuario/:_id', { _id: '@_id' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Empresas', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/empresas/:idEmpresa', { idEmpresa: '@idEmpresa' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Clientes', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/clientes/:idCliente', { idCliente: '@idCliente' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('Produtos', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/produtos/:idNfeDet', { idNfeDet: '@idNfeDet' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);

	angular.module('acnf.common').factory('MunicipiosEstado', ["$resource", "$http", "$config", function ($resource, $http, $config) {
		return $resource($config.api + '/api/estados/:idEnumMunicipio/municipios', { idEnumMunicipio: '@idEnumMunicipio' }, {
			'update': {
				method: 'PUT'
			}
		});
	}]);
})();
(function () {
	// Generic query and get methods
	var _query = function _query(list) {
		return list;
	};

	function _get(list, id) {
		for (var i = 0, n = list.length; i < n; i++) {
			if (list[i].id === id) {
				return list[i];
			}
		}
	}

	angular.module('acnf.common').service('listaEstados', function () {
		var list = [{ id: 0, sigla: 'TD', descricao: 'Todos' }, { id: 11, sigla: 'RO', descricao: 'Rondônia' }, { id: 12, sigla: 'AC', descricao: 'Acre' }, { id: 13, sigla: 'AM', descricao: 'Amazonas' }, { id: 14, sigla: 'RR', descricao: 'Roraima' }, { id: 15, sigla: 'PA', descricao: 'Pará' }, { id: 16, sigla: 'AP', descricao: 'Amapá' }, { id: 17, sigla: 'TO', descricao: 'Tocantis' }, { id: 21, sigla: 'MA', descricao: 'Maranhão' }, { id: 22, sigla: 'PI', descricao: 'Piauí' }, { id: 23, sigla: 'CE', descricao: 'Ceará' }, { id: 24, sigla: 'RN', descricao: 'Rio Grande do Norte' }, { id: 25, sigla: 'PB', descricao: 'Paraíba' }, { id: 26, sigla: 'PE', descricao: 'Pernambuco' }, { id: 27, sigla: 'AL', descricao: 'Alagoas' }, { id: 28, sigla: 'SE', descricao: 'Sergipe' }, { id: 29, sigla: 'BA', descricao: 'Bahia' }, { id: 31, sigla: 'MG', descricao: 'Minas Gerais' }, { id: 32, sigla: 'ES', descricao: 'Espírito Santo' }, { id: 33, sigla: 'RJ', descricao: 'Rio de Janeiro' }, { id: 35, sigla: 'SP', descricao: 'São Paulo' }, { id: 41, sigla: 'PR', descricao: 'Paraná' }, { id: 42, sigla: 'SC', descricao: 'Santa Catarina' }, { id: 43, sigla: 'RS', descricao: 'Rio Grande do Sul' }, { id: 50, sigla: 'MS', descricao: 'Mato Grosso do Sul' }, { id: 51, sigla: 'MT', descricao: 'Mato Grosso' }, { id: 52, sigla: 'GO', descricao: 'Goiás' }, { id: 53, sigla: 'DF', descricao: 'Distrito Federal' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});

	angular.module('acnf.common').service('listaMunicipios', ["$q", "$acnfNotify", "MunicipiosEstado", function ($q, $acnfNotify, MunicipiosEstado) {
		return {
			query: function query(idEnumMunicipio) {
				var deferred = $q.defer();
				var promise = MunicipiosEstado.query({ idEnumMunicipio: idEnumMunicipio }).$promise;

				promise.then(function (response) {
					deferred.resolve(response);
				}).catch(function () {
					$acnfNotify.error('Ocorreu um erro ao buscar as cidades.');
				});

				return deferred.promise;
			}
		};
	}]);

	angular.module('acnf.common').service('listaTipoPessoa', function () {
		var list = [{ id: 0, descricao: 'Pessoa Física' }, { id: 1, descricao: 'Pessoa Jurídica' }, { id: 2, descricao: 'Estrangeiro' }];

		return {
			query: function query() {
				return _query(list);
			},
			get: function get(id) {
				return _get(list, id);
			}
		};
	});
})();
(function () {
	'use strict';

	angular.module('acnf.components', []);
})();

var AcnfComboMunicipios = function (_AcnfComponent2) {
	_inherits(AcnfComboMunicipios, _AcnfComponent2);

	function AcnfComboMunicipios(listaMunicipios) {
		_classCallCheck(this, AcnfComboMunicipios);

		var _this14 = _possibleConstructorReturn(this, (AcnfComboMunicipios.__proto__ || Object.getPrototypeOf(AcnfComboMunicipios)).call(this));

		_this14.restrict = 'E';
		_this14.templateUrl = 'components/comboMunicipios/comboMunicipios.html';
		_this14.listaMunicipios = listaMunicipios;
		_this14.scope = {
			entity: '='
		};
		return _this14;
	}

	_createClass(AcnfComboMunicipios, [{
		key: 'linkComponent',
		value: function linkComponent($scope, $element, $attributes) {
			var _this15 = this;

			$scope.$watch('entity.idEnumEstado', function (newValue, oldValue) {
				$scope.isLoadingMunicipios = true;

				var isDefined = angular.isDefined;

				if (isDefined(newValue) && isDefined(oldValue) && newValue !== oldValue) {
					$scope.entity.idEnumMunicipio = null;
					$scope.placeholderMunicipios = null;
				}

				if ($scope.entity && isDefined($scope.entity.idEnumEstado)) {
					_this15.listaMunicipios.query($scope.entity.idEnumEstado).then(function (response) {
						$scope.placeholderMunicipios = 'Selecione a Cidade...';
						$scope.isLoadingMunicipios = false;
						$scope.listaMunicipios = response;
					});
				}
			});
		}
	}], [{
		key: 'directiveFactory',
		value: ["listaMunicipios", function directiveFactory(listaMunicipios) {
			"ngInject";

			AcnfComboMunicipios.instance = new AcnfComboMunicipios(listaMunicipios);
			return AcnfComboMunicipios.instance;
		}]
	}]);

	return AcnfComboMunicipios;
}(AcnfComponent);

angular.module('acnfFramework.components').directive('acnfComboMunicipios', AcnfComboMunicipios.directiveFactory);